/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_MAP_ST_H
#define CTSL_MAP_ST_H


#include "defs.h"

//map may contain as values different data types like Python Dictionary


CTSL_API map_t * map_create(ctl_compare comp_key_fn, ctl_before_destroy destroy_key_fn, ctl_before_destroy destroy_value_fn);
CTSL_API STATUS map_insert(map_t* map, void* key, size_t key_size, object_type_t key_type, void* value, size_t value_size, object_type_t value_type);
CTSL_API STATUS map_replace_value(map_t* map, void* key, size_t key_size, object_type_t key_type, void* value, size_t value_size, object_type_t value_type);
CTSL_API bool map_contains_key(map_t* map, void* key, size_t key_size, object_type_t key_type);
CTSL_API bool map_contains_value(map_t* map, void* value, ctl_compare value_compare_fn);
CTSL_API STATUS map_key_remove(map_t* map, void* key, size_t key_size, object_type_t key_type);
CTSL_API STATUS map_value_by_key(map_t* map, void* key, size_t key_size, object_type_t key_type, void* value);
CTSL_API STATUS map_object_by_key(map_t* map, void* key, size_t key_size, object_type_t key_type, object_t* item);
CTSL_API STATUS map_clear(map_t* map);
CTSL_API STATUS map_delete(map_t* map);
CTSL_API size_t map_size(map_t* map);

CTSL_API iterator_t* map_create_iterator(map_t* map);
CTSL_API void map_delete_iterator(iterator_t* iterator);
CTSL_API void map_reset_iterator(iterator_t* iterator);


#endif //CTSL_MAP_ST_H
