/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_QUEUE_H
#define CTSL_QUEUE_H

#include "defs.h"

//Strong Type Queue: may contain same data type items like vector_st_t.
//All items are copied and saved in internal storage.
//Preferred for real-time tasks (much faster than queue_gn_t).

//strong type queue
CTSL_API queue_st_t* qus_create(size_t queue_size, size_t item_size, bool auto_resize);
CTSL_API void qus_delete(queue_st_t** queue);
CTSL_API STATUS qus_push(queue_st_t* queue, void* item);
CTSL_API void* qus_pop(queue_st_t* queue); /* the return value is stored in memory until the next call to qus_pop */
CTSL_API void qus_clear(queue_st_t* queue);
CTSL_API const void* qus_item(queue_st_t* queue, size_t index);
CTSL_API size_t qus_size(queue_st_t* queue);
CTSL_API bool qus_is_empty(queue_st_t* queue);

CTSL_API iterator_t* qus_create_iterator(queue_st_t* queue);
CTSL_API void qus_delete_iterator(iterator_t* iterator);
CTSL_API void qus_reset_iterator(iterator_t* iterator);




//Queue: may contain different data types items in same storage like Python List.
//All items are copied and saved in internal storage.
//For real-time tasks usage of queue_st_t is preferred.
typedef struct queue_gn_s queue_gn_t;

CTSL_API queue_gn_t* qug_create(size_t queue_size, bool auto_resize);
CTSL_API void qug_delete(queue_gn_t** queue);
CTSL_API STATUS qug_push(queue_gn_t* queue, void* item, size_t item_size, object_type_t item_type);
CTSL_API object_t* qug_pop(queue_gn_t* queue);  /* the return value is stored in memory until the next call to qus_pop */
CTSL_API void qug_clear(queue_gn_t* queue);
CTSL_API const object_t* qug_item(queue_gn_t* queue, size_t index);
CTSL_API size_t qug_size(queue_gn_t* queue);
CTSL_API bool qug_is_empty(queue_gn_t* queue);

CTSL_API iterator_t* qug_create_iterator(queue_gn_t* queue);
CTSL_API void qug_delete_iterator(iterator_t* iterator);
CTSL_API void qug_reset_iterator(iterator_t* iterator);

#endif //CTSL_QUEUE_H
