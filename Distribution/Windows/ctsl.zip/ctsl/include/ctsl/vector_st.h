/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_VECTOR_ST_H
#define CTSL_VECTOR_ST_H

#include "defs.h"

//Strong Type Vector: may contain same data type items like STL vector.
//All items are copied and saved to the internal storage.
//Preferred for real-time tasks (much faster than vector_gn_t).

CTSL_API vector_st_t* vect_create(size_t init_size, size_t item_size, ctl_before_destroy fn_d);
CTSL_API vector_st_t* vect_clone(vector_st_t* src_vec, ctl_before_destroy fn_d);
CTSL_API STATUS vect_resize(vector_st_t* vec, size_t new_size);
CTSL_API STATUS vect_push_back(vector_st_t* vec, void* item);
CTSL_API const void* vect_item_direct(vector_st_t* vec, size_t index);  //fast access without checks!
CTSL_API STATUS vect_item(vector_st_t* vec, size_t index, void* item); //safe access!
CTSL_API STATUS vect_insert_item(vector_st_t* vec, size_t index, void* item);
CTSL_API STATUS vect_replace_item(vector_st_t* vec, size_t index, void* item);
CTSL_API size_t vect_size(vector_st_t* vec);
CTSL_API size_t vect_capacity(vector_st_t* vec);
CTSL_API bool vect_is_empty(vector_st_t* vec);
CTSL_API long vect_find_item(vector_st_t* vec, void* value, ctl_compare compare_values_fn); /* uses binary compare in case of compare_fn == NULL */
CTSL_API STATUS vect_sort(vector_st_t* vec, ctl_compare compare_values_fn);
CTSL_API STATUS vect_sort_ex(vector_st_t* vec, ctl_compare compare_values_fn, size_t index, size_t size);
CTSL_API STATUS vect_revert(vector_st_t* vec);
CTSL_API STATUS vect_front(vector_st_t* vec, void** item);
CTSL_API STATUS vect_back(vector_st_t* vec, void** item);
CTSL_API STATUS vect_remove_item(vector_st_t* vec, size_t index);
CTSL_API STATUS vect_remove_range(vector_st_t* vec, size_t start_index, size_t items_count);
CTSL_API STATUS vect_clear(vector_st_t* vec);
CTSL_API STATUS vect_delete(vector_st_t* vec);
CTSL_API STATUS vect_swap(vector_st_t* vec, size_t index0, size_t index1);
CTSL_API STATUS vect_swap_range(vector_st_t* vec, size_t start_index0, size_t start_index1, size_t items_count);

CTSL_API iterator_t* vect_create_iterator(vector_st_t* vec);
CTSL_API void vect_delete_iterator(iterator_t* iterator);
CTSL_API void vect_reset_iterator(iterator_t* iterator);

#endif //CTSL_VECTOR_ST_H
