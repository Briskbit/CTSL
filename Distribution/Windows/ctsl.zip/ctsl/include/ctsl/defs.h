/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_DEFS_H
#define CTSL_DEFS_H

#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include<string.h>

#ifdef _WIN32 
#include <windows.h>
#define CTSL_API __declspec(dllexport)
#define STDCLL	__stdcall

#elif __linux__
#include <nl_types.h>
#define CTSL_API
#define STDCLL

#elif __APPLE__
#define CTSL_API
#define STDCLL

#endif


#define in
#define out
#define in_out
#define opt
#define NORV

#define STATUS_OK   0
typedef int         STATUS;

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __cplusplus
#ifdef DEFINE_BOOL
typedef int         bool;
#define true        1
#define false       0
#endif //DEFINE_BOOL
#endif //__cplusplus

#define INVALID_RESULT  (size_t)-1

#ifndef FAILED
#define FAILED(status)      ((status) != STATUS_OK)
#endif //FAILED

#ifndef SUCCEEDED
#define SUCCEEDED(status)   ((status) == STATUS_OK)
#endif //SUCCEEDED


/* ---------------------  Error codes  ------------------------------- */
#define CTL_ERROR_CODES_BASE                 -100000
#define CTL_OUT_OF_MEMORY                    (CTL_ERROR_CODES_BASE + 1)
#define CTL_INVALID_POINTER                  (CTL_ERROR_CODES_BASE + 2)
#define CTL_INVALID_SIZE                     (CTL_ERROR_CODES_BASE + 3)
#define CTL_INVALID_REFERENCE                (CTL_ERROR_CODES_BASE + 4)
#define CTL_DUPLICATE_KEY                    (CTL_ERROR_CODES_BASE + 5)
#define CTL_NODE_NOT_FOUND                   (CTL_ERROR_CODES_BASE + 6)
#define CTL_MAP_NOT_INITIALIZED              (CTL_ERROR_CODES_BASE + 7)
#define CTL_VECTOR_NOT_INITIALIZED           (CTL_ERROR_CODES_BASE + 8)
#define CTL_VECTOR_INDEX_OUT_OF_BOUND        (CTL_ERROR_CODES_BASE + 9)
#define CTL_MAP_KEY_NOT_FOUND                (CTL_ERROR_CODES_BASE + 10)
#define CTL_SLIST_NOT_INITIALIZED            (CTL_ERROR_CODES_BASE + 11)
#define CTL_SLIST_ITEM_NOT_FOUND             (CTL_ERROR_CODES_BASE + 12)
#define CTL_SLIST_INVALID_INDEX              (CTL_ERROR_CODES_BASE + 13)
#define CTL_VECTOR_INVALID_INDICES           (CTL_ERROR_CODES_BASE + 14)
#define CTL_VECTOR_INVALID_RANGE             (CTL_ERROR_CODES_BASE + 15)
#define CTL_MAP_INVALID_ITEM_POINTER         (CTL_ERROR_CODES_BASE + 16)
#define CTL_QUEUE_NOT_INITIALIZED            (CTL_ERROR_CODES_BASE + 17)
#define CTL_QUEUE_IS_FULL                    (CTL_ERROR_CODES_BASE + 18)
#define CTL_QUEUE_IS_EMPTY                   (CTL_ERROR_CODES_BASE + 19)
#define CTL_STRING_NOT_CREATED               (CTL_ERROR_CODES_BASE + 20)
#define CTL_STRING_INDEX_OUT_OF_BOUND        (CTL_ERROR_CODES_BASE + 21)
#define CTL_STRING_INVALID_INPUT_STRING      (CTL_ERROR_CODES_BASE + 22)
#define CTL_STRING_INVALID_OBJECT            (CTL_ERROR_CODES_BASE + 23)
#define CTL_STRING_SUBSTRING_OUT_OF_BOUND    (CTL_ERROR_CODES_BASE + 24)
#define CTL_STRING_INVALID_LENGTH            (CTL_ERROR_CODES_BASE + 25)
#define CTL_STRING_INVALID_CHAR              (CTL_ERROR_CODES_BASE + 26)
#define CTL_STRING_INVALID_RANGE             (CTL_ERROR_CODES_BASE + 27)
#define CTL_SUBSTRING_INVALID_RANGE          (CTL_ERROR_CODES_BASE + 28)

/* ---------------------  End Error codes  --------------------------- */


#ifndef __cplusplus
#ifdef DEFINE_BOOL
#define true        1
#define false       0
typedef int         bool;
#endif // DEFINE_BOOL
#endif //__cplusplus

#define __ctl_cvt__(type, obj)      ((type)(obj))
#define __ctl_val__(type, obj)      (*__ctl_cvt__((type)*, (obj)))

#ifdef _WIN32 

#define tmalloca(type, size, alin)  (type*)_aligned_malloc((size), (alin))
#define freea(p)                    if ((p)) { _aligned_free((p)); (p) = NULL; }
#define _always_inline_             __forceinline 

#elif __linux__

#define __CTL_LIB_CTOR__ \
__attribute__((__used__)) \
__attribute__((__noinline__)) \
__attribute__((__constructor__(101))) \
void __ctor__(void)

#define __CTL_LIB_DTOR__ \
__attribute__((__used__)) \
__attribute__((__noinline__)) \
__attribute__((__destructor__(101))) \
void __dtor__(void)

#define __LIB_CTOR_EX__(fname) \
__attribute__((__used__)) \
__attribute__((__noinline__)) \
__attribute__((__constructor__(101))) \
void _##fname##_ctor__(void)

#define __LIB_DTOR_EX__(fname) \
__attribute__((__used__)) \
__attribute__((__noinline__)) \
__attribute__((__destructor__(101))) \
void __##fname##_dtor__(void)


#define tmalloca(type, size, alin)  (type*)aligned_alloc((alin),(size))
#define freea(p)                    if ((p)) { free((p)); (p) = NULL; }
#define _always_inline_             __always_inline
#elif __APPLE__
#endif


#define tmalloc(type, size)         (type*)calloc(1, size)
#define del(p)                      if ((p)) { free((p)); (p) = NULL; }
#define CTL_FAILED(status)          ((status) != STATUS_OK)
#define UNREF_PARAM(x)              x=x

#ifndef MIN
#define MIN(a,b)                ((a) < (b) ? (a) : (b))
#endif

#define validate_mem(p, ret)            if(!(p)) return ret;
#define validate_status(status, ret)    if((status) != STATUS_OK) return (ret);


typedef enum{
    tsSeconds = 0,
    tsMilliSeconds,
    tsMicroSeconds,
    tsNanoSeconds
}time_spec;


/* max enum valaue should be < 0xFFFF */
CTSL_API typedef enum object_type_e{
    otUnknown = 0,
    otInt8,
    otUInt8,
    otInt16,
    otUInt16,
    otInt32,
    otUInt32,
    otInt64,
    otUInt64,
    otFloat,
    otDouble,
    otCharPtr,
    otWCharPtr,
    otPointer,
}object_type_t;


typedef struct CTSL_API cust_s {
    int8_t(* const getInt8)(const void* data);
    uint8_t(* const getUint8)(const void* data);
    int16_t(* const getInt16)(const void* data);
    uint16_t(* const getUint16)(const void* data);
    int32_t(* const getInt32)(const void* data);
    uint32_t(* const getUint32)(const void* data);
    int64_t(* const getInt64)(const void* data);
    uint64_t(* const getUint64)(const void* data);
    float(* const getFloat)(const void* data);
    double(* const getDouble)(const void* data);
    const char* (* const getCharPtr)(const void* data);
    const wchar_t* (* const getWCharPtr)(const void* data);
    const void* (* const getPointer)(const void* data);
}cust_t;


typedef struct cust_s cust_t;


CTSL_API int8_t STDCLL getInt8(const void* data);
CTSL_API uint8_t STDCLL getUint8(const void* data);
CTSL_API int16_t STDCLL getInt16(const void* data);
CTSL_API uint16_t STDCLL getUint16(const void* data);
CTSL_API int32_t STDCLL getInt32(const void* data);
CTSL_API uint32_t STDCLL getUint32(const void* data);
CTSL_API int64_t STDCLL getInt64(const void* data);
CTSL_API uint64_t STDCLL getUint64(const void* data);
CTSL_API float STDCLL getFloat(const void* data);
CTSL_API double STDCLL getDouble(const void* data);
CTSL_API const char* STDCLL getCharPtr(const void* data);
CTSL_API const wchar_t* STDCLL getWCharPtr(const void* data);
CTSL_API const void* STDCLL getPointer(const void* data);
 


static const cust_t cust = {
     .getInt8 = getInt8,
     .getUint8 = getUint8,
     .getInt16 = getInt16,
     .getUint16 = getUint16,
     .getInt32 = getInt32,
     .getUint32 = getUint32,
     .getInt64 = getInt64,
     .getUint64 = getUint64,
     .getFloat = getFloat,
     .getDouble = getDouble,
     .getCharPtr = getCharPtr,
     .getWCharPtr = getWCharPtr,
     .getPointer = getPointer,
 };


typedef struct object_s {
    void* data;
    size_t size;
    object_type_t type;
}object_t;


typedef struct iterator_s {
    void (*replace_item)(struct iterator_s*, void* item, size_t size, object_type_t type);
    bool (*next)(struct iterator_s*);
    object_t* value;
    object_t* key;
    void* context; /* internal */
}iterator_t;


typedef void (*ctl_before_destroy)(const void*);
typedef int  (*ctl_compare)(const void*, const void*);

typedef struct ctl_timer_s {
    void(STDCLL *start)();
    double(STDCLL *stop)(const time_spec tspec);
}ctl_timer_t;

//CTSL_API extern const ctl_timer_t timer;

CTSL_API void STDCLL start();
CTSL_API double STDCLL stop(const time_spec tspec);


static const ctl_timer_t timer = {
    .start = start,
    .stop = stop,
};

typedef struct string_a_s string_a;
typedef struct string_w_s string_w;
typedef struct vector_gn_s vector_gn_t;
typedef struct vector_st_s vector_st_t;
typedef struct slist_s slist_t;
typedef struct queue_st_s queue_st_t;
typedef struct map_s map_t;

#ifdef __cplusplus
}
#endif

#endif //CTSL_DEFS_H
