/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_CTSL_H
#define CTSL_CTSL_H
/*
*  ----------------------- C Tools Library -------------------------
*/
#ifdef __cplusplus
extern "C" {
#endif

#include "defs.h"
#include "map.h"
#include "vector_st.h"
#include "vector_gn.h"
#include "slist.h"
#include "queue.h"
#include "string_ctl.h"


/*-------------- common utils ---------------------*/
CTSL_API STATUS create_object(const void* item_data, const size_t item_size, object_type_t item_type, object_t** ppObject);
CTSL_API STATUS create_object_attach_data(const void* item_data, const size_t item_size, object_type_t item_type, object_t** ppObject);
CTSL_API void delete_object(object_t** object);
CTSL_API void delete_object_attached(object_t** object);
CTSL_API STATUS clone_object(const object_t* object, object_t** new_object);
CTSL_API int64_t get_time(const time_spec ts); /*returns time since OS start*/

#define time_nano_sec   get_time(tsNanoSeconds)
#define time_micro_sec  get_time(tsMicroSeconds)
#define time_milli_sec  get_time(tsMilliSeconds)
#define time_sec        get_time(tsSeconds)

#ifdef __cplusplus
}
#endif

#endif //CTSL_CTSL_H
