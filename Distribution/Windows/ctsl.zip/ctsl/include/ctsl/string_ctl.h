/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_STRING_H
#define CTSL_STRING_H

#include "defs.h"

///// string_a
/* constructors */
CTSL_API string_a* stra_create();
CTSL_API string_a* stra_from_stra(const string_a* stra);
CTSL_API string_a* stra_from_str(const char* str);
CTSL_API string_a* stra_from_chr(char ch);
CTSL_API string_a* stra_from_strw(const string_w* strw);
CTSL_API string_a* stra_from_wstr(const wchar_t* str);

CTSL_API string_a* stra_add_chr(const string_a* stra, char ch); //stra + ch
CTSL_API string_a* stra_add_str(const string_a* stra, const char* str); //stra + str
CTSL_API string_a* stra_add_stra(const string_a* stra, string_a* stra2); //stra + stra

/* methods */
CTSL_API size_t stra_length(const string_a* obj);
CTSL_API const char* stra_c_str(const string_a* obj);
CTSL_API bool stra_is_empty(const string_a* obj);
CTSL_API STATUS stra_clear(string_a* obj);
CTSL_API STATUS stra_remove_range(string_a* obj, size_t start_index, size_t length);
#define stra_erase stra_remove_range
CTSL_API STATUS stra_delete(string_a** obj);

CTSL_API STATUS stra_append_chr(string_a* obj, char ch);
CTSL_API STATUS stra_append_str(string_a* obj, const char* str);
CTSL_API STATUS stra_append_stra(string_a* obj, const string_a* stra);
CTSL_API STATUS stra_insert_chr(string_a* obj, char ch, size_t pos);
CTSL_API STATUS stra_insert_str(string_a* obj, const char* str, size_t pos);
CTSL_API STATUS stra_insert_stra(string_a* obj, const string_a* stra, size_t pos);
CTSL_API STATUS stra_assign_chr(string_a* obj, char ch);
CTSL_API STATUS stra_assign_str(string_a* obj, const char* str);
CTSL_API STATUS stra_assign_stra(string_a* obj, const string_a* stra);

CTSL_API int stra_compare_str(const string_a* obj, const char* str);
CTSL_API int stra_compare_stra(const string_a* obj, const string_a* stra);
CTSL_API int stra_compare_substr(const string_a* obj, size_t pos, size_t len, const char* str);
CTSL_API int stra_compare_substra(const string_a* obj, size_t pos, size_t len, const string_a* stra);
CTSL_API bool stra_contains_str(const string_a* obj, const char* str);
CTSL_API bool stra_contains_stra(const string_a* obj, const string_a* stra);

CTSL_API size_t stra_find_chr(const string_a* obj, char ch, size_t pos);
CTSL_API size_t stra_find_str(const string_a* obj, const char* str, size_t pos);
CTSL_API size_t stra_find_stra(const string_a* obj, const string_a* stra, size_t pos);
CTSL_API size_t stra_find_first_chr(const string_a* obj, char ch);
CTSL_API size_t stra_find_first_str(const string_a* obj, const char* str);
CTSL_API size_t stra_find_first_stra(const string_a* obj, const string_a* stra);
CTSL_API size_t stra_find_last_chr(const string_a* obj, char ch);
CTSL_API size_t stra_find_last_str(const string_a* obj, const char* str);
CTSL_API size_t stra_find_last_stra(const string_a* obj, const string_a* stra);

CTSL_API bool stra_starts_with_chr(string_a* obj, char ch);
CTSL_API bool stra_starts_with_str(string_a* obj, const char* str);
CTSL_API bool stra_starts_with_stra(string_a* obj, const string_a* stra);
CTSL_API bool stra_ends_with_chr(string_a* obj, char ch);
CTSL_API bool stra_ends_with_str(string_a* obj, const char* str);
CTSL_API bool stra_ends_with_stra(string_a* obj, const string_a* stra);
CTSL_API STATUS stra_reverse(string_a* obj);
CTSL_API STATUS stra_reverse_range(string_a* obj, size_t pos, size_t len);
CTSL_API string_a* stra_substr(const string_a* obj, size_t pos, size_t len);
CTSL_API STATUS stra_swap_range(string_a* obj, size_t pos0, size_t pos1, size_t len);

CTSL_API STATUS stra_replace_chr(string_a* obj, size_t pos, size_t len, char ch, size_t n); //Replaces the portion of the string by n consecutive copies of character ch
CTSL_API STATUS stra_replace_str(string_a* obj, size_t pos, size_t len, const char* str);
CTSL_API STATUS stra_replace_stra(string_a* obj, size_t pos, size_t len, const string_a* stra);
CTSL_API STATUS stra_replace_strex(string_a* obj, size_t pos, size_t len, const char* str, size_t spos, size_t slen); //Copies the portion of str that begins at the character position subpos and spans sublen characters
CTSL_API STATUS stra_replace_straex(string_a* obj, size_t pos, size_t len, const string_a* stra, size_t spos, size_t slen);

CTSL_API float stra_stof(const string_a* obj); //If no valid conversion could be performed, it returns zero (0.0).
CTSL_API double stra_stod(const string_a* obj); //If no valid conversion could be performed, it returns zero (0.0).
CTSL_API long double stra_stold(const string_a* obj); //If no valid conversion could be performed, it returns zero (0.0).
CTSL_API int stra_stoi(const string_a* obj);   //If no valid conversion could be performed, it returns 0.
CTSL_API long stra_stol(const string_a* obj);  //If no valid conversion could be performed, it returns LONG_MIN/LONG_MAX.
CTSL_API long long stra_stoll(const string_a* obj);  //If no valid conversion could be performed, it returns LLONG_MIN/LLONG_MAX.
CTSL_API unsigned int stra_stou(const string_a* obj);   //If no valid conversion could be performed, it returns 0.
CTSL_API unsigned long stra_stoul(const string_a* obj);   //If no valid conversion could be performed, it returns 0.
CTSL_API unsigned long long stra_stoull(const string_a* obj);  //If no valid conversion could be performed, it returns ULONG_MAX/ULLONG_MAX.

CTSL_API string_a* stra_ftos(float value);
CTSL_API string_a* stra_dtos(double value);
CTSL_API string_a* stra_ldtos(long double value);
CTSL_API string_a* stra_itos(int value);
CTSL_API string_a* stra_ltos(long value);
CTSL_API string_a* stra_lltos(long long value);
CTSL_API string_a* stra_utos(unsigned int value);
CTSL_API string_a* stra_ultos(unsigned long value);
CTSL_API string_a* stra_ulltos(unsigned long long value);

//splitter
CTSL_API vector_st_t* stra_create_splitter_chr(string_a* obj, char delimeter);
CTSL_API vector_st_t* stra_create_splitter_str(string_a* obj, const char* delimeter);
CTSL_API vector_st_t* stra_create_splitter_stra(string_a* obj, const string_a* delimeter);
CTSL_API STATUS stra_delete_splitter(vector_st_t* splitter);



///// string_w
/* constructors */
CTSL_API string_w* strw_create();
CTSL_API string_w* strw_from_strw(const string_w* strw);
CTSL_API string_w* strw_from_str(const wchar_t* str);
CTSL_API string_w* strw_from_chr(wchar_t ch);
CTSL_API string_w* strw_from_stra(const string_a* stra);
CTSL_API string_w* strw_from_astr(const char* str);

CTSL_API string_w* strw_add_chr(const string_w* strw, wchar_t ch);
CTSL_API string_w* strw_add_str(const string_w* strw, const wchar_t* str);
CTSL_API string_w* strw_add_strw(const string_w* strw, string_w* strw2);

/* methods */
CTSL_API size_t strw_length(const string_w* obj);
CTSL_API const wchar_t* strw_c_str(const string_w* obj);
CTSL_API bool strw_is_empty(const string_w* obj);
CTSL_API STATUS strw_clear(string_w* obj);
CTSL_API STATUS strw_remove_range(string_w* obj, size_t start_index, size_t length);
#define strw_erase strw_remove_range
CTSL_API STATUS strw_delete(string_w** obj);

CTSL_API STATUS strw_append_chr(string_w* obj, wchar_t ch);
CTSL_API STATUS strw_append_str(string_w* obj, const wchar_t* str);
CTSL_API STATUS strw_append_strw(string_w* obj, const string_w* strw);
CTSL_API STATUS strw_insert_chr(string_w* obj, wchar_t ch, size_t pos);
CTSL_API STATUS strw_insert_str(string_w* obj, const wchar_t* str, size_t pos);
CTSL_API STATUS strw_insert_strw(string_w* obj, const string_w* strw, size_t pos);
CTSL_API STATUS strw_assign_chr(string_w* obj, wchar_t ch);
CTSL_API STATUS strw_assign_str(string_w* obj, const wchar_t* str);
CTSL_API STATUS strw_assign_strw(string_w* obj, const string_w* strw);

CTSL_API int strw_compare_str(const string_w* obj, const wchar_t* str);
CTSL_API int strw_compare_strw(const string_w* obj, const string_w* strw);
CTSL_API int strw_compare_substr(const string_w* obj, size_t pos, size_t len, const wchar_t* str);
CTSL_API int strw_compare_substrw(const string_w* obj, size_t pos, size_t len, const string_w* strw);
CTSL_API bool strw_contains_str(const string_w* obj, const wchar_t* str);
CTSL_API bool strw_contains_strw(const string_w* obj, const string_w* strw);

CTSL_API size_t strw_find_chr(const string_w* obj, wchar_t ch, size_t pos);
CTSL_API size_t strw_find_str(const string_w* obj, const wchar_t* str, size_t pos);
CTSL_API size_t strw_find_strw(const string_w* obj, const string_w* strw, size_t pos);
CTSL_API size_t strw_find_first_chr(const string_w* obj, wchar_t ch);
CTSL_API size_t strw_find_first_str(const string_w* obj, const wchar_t* str);
CTSL_API size_t strw_find_first_strw(const string_w* obj, const string_w* strw);
CTSL_API size_t strw_find_last_chr(const string_w* obj, wchar_t ch);
CTSL_API size_t strw_find_last_str(const string_w* obj, const wchar_t* str);
CTSL_API size_t strw_find_last_strw(const string_w* obj, const string_w* strw);

CTSL_API bool strw_starts_with_wchr(string_w* obj, wchar_t ch);
CTSL_API bool strw_starts_with_wstr(string_w* obj, const wchar_t* str);
CTSL_API bool strw_starts_with_strw(string_w* obj, const string_w* strw);
CTSL_API bool strw_ends_with_wchr(string_w* obj, wchar_t ch);
CTSL_API bool strw_ends_with_wstr(string_w* obj, const wchar_t* str);
CTSL_API bool strw_ends_with_strw(string_w* obj, const string_w* strw);
CTSL_API STATUS strw_reverse(string_w* obj);
CTSL_API STATUS strw_reverse_range(string_w* obj, size_t pos, size_t len);
CTSL_API string_w* strw_substr(const string_w* obj, size_t pos, size_t len);
CTSL_API STATUS strw_swap_range(string_w* obj, size_t pos0, size_t pos1, size_t len);

CTSL_API STATUS strw_replace_chr(string_w* obj, size_t pos, size_t len, wchar_t ch, size_t n); //Replaces the portion of the string by n consecutive copies of character ch
CTSL_API STATUS strw_replace_str(string_w* obj, size_t pos, size_t len, const wchar_t* str);
CTSL_API STATUS strw_replace_strw(string_w* obj, size_t pos, size_t len, const string_w* strw);
CTSL_API STATUS strw_replace_strex(string_w* obj, size_t pos, size_t len, const wchar_t* str, size_t spos, size_t slen); //Copies the portion of str that begins at the character position subpos and spans sublen characters
CTSL_API STATUS strw_replace_strwex(string_w* obj, size_t pos, size_t len, const string_w* strw, size_t spos, size_t slen);

CTSL_API float strw_stof(const string_w* obj); //If no valid conversion could be performed, it returns zero (0.0).
CTSL_API double strw_stod(const string_w* obj); //If no valid conversion could be performed, it returns zero (0.0).
CTSL_API long double strw_stold(const string_w* obj); //If no valid conversion could be performed, it returns zero (0.0).
CTSL_API int strw_stoi(const string_w* obj);   //If no valid conversion could be performed, it returns 0.
CTSL_API long strw_stol(const string_w* obj);  //If no valid conversion could be performed, it returns LONG_MIN/LONG_MAX.
CTSL_API long long strw_stoll(const string_w* obj);  //If no valid conversion could be performed, it returns LLONG_MIN/LLONG_MAX.
CTSL_API unsigned int strw_stou(const string_w* obj);   //If no valid conversion could be performed, it returns 0.
CTSL_API unsigned long strw_stoul(const string_w* obj);   //If no valid conversion could be performed, it returns 0.
CTSL_API unsigned long long strw_stoull(const string_w* obj);  //If no valid conversion could be performed, it returns ULONG_MAX/ULLONG_MAX.

CTSL_API string_w* strw_ftos(float value);
CTSL_API string_w* strw_dtos(double value);
CTSL_API string_w* strw_ldtos(long double value);
CTSL_API string_w* strw_itos(int value);
CTSL_API string_w* strw_ltos(long value);
CTSL_API string_w* strw_lltos(long long value);
CTSL_API string_w* strw_utos(unsigned int value);
CTSL_API string_w* strw_ultos(unsigned long value);
CTSL_API string_w* strw_ulltos(unsigned long long value);


//splitter_w
CTSL_API vector_st_t* strw_create_splitter_chr(string_w* obj, wchar_t delimeter);
CTSL_API vector_st_t* strw_create_splitter_str(string_w* obj, const wchar_t* delimeter);
CTSL_API vector_st_t* strw_create_splitter_stra(string_w* obj, const string_w* delimeter);
CTSL_API STATUS strw_delete_splitter(vector_st_t* splitter);

#endif //CTSL_STRING_H
