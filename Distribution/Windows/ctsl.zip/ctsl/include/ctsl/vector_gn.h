/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_VECTOR_GN_H
#define CTSL_VECTOR_GN_H

#include "defs.h"

//Vector: may contain different data types items in same vector like Python List.
//All items are copied and saved to the internal storage.
//For real-time tasks, vector_st_t is preferable.

CTSL_API vector_gn_t* vecg_create(size_t init_size, ctl_before_destroy fn_d);
CTSL_API vector_gn_t* vecg_clone(vector_gn_t* src_vec, ctl_before_destroy fn_d);
CTSL_API STATUS vecg_resize(vector_gn_t* vec, size_t new_size);
CTSL_API STATUS vecg_push_back(vector_gn_t* vec, void* item, size_t item_size, object_type_t item_type);
CTSL_API STATUS vecg_item(vector_gn_t* vec, size_t index, object_t* item);
CTSL_API STATUS vecg_insert_item(vector_gn_t* vec, size_t index, void* item, size_t item_size, object_type_t item_type);
CTSL_API STATUS vecg_replace_item(vector_gn_t* vec, size_t index, void* item, size_t item_size, object_type_t item_type);
CTSL_API size_t vecg_size(vector_gn_t* vec);
CTSL_API size_t vecg_capacity(vector_gn_t* vec);
CTSL_API bool vecg_is_empty(vector_gn_t* vec);
CTSL_API long vecg_find_item(vector_gn_t* vec, void* item, size_t item_size, object_type_t item_type, ctl_compare compare_fn); /* uses binary compare in case of compare_fn == NULL */
CTSL_API STATUS vecg_sort(vector_gn_t* vec, ctl_compare compare_fn);
CTSL_API STATUS vecg_sort_ex(vector_gn_t* vec, ctl_compare compare_values_fn, size_t index, size_t size);
CTSL_API STATUS vecg_revert(vector_gn_t* vec);
CTSL_API STATUS vecg_front(vector_gn_t* vec, object_t* item);
CTSL_API STATUS vecg_back(vector_gn_t* vec, object_t* item);
CTSL_API STATUS vecg_remove_item(vector_gn_t* vec, size_t index);
CTSL_API STATUS vecg_remove_range(vector_gn_t* vec, size_t start_index, size_t items_count);
CTSL_API STATUS vecg_clear(vector_gn_t* vec);
CTSL_API STATUS vecg_delete(vector_gn_t* vec);
CTSL_API STATUS vecg_swap(vector_gn_t* vec, size_t index0, size_t index1);
CTSL_API STATUS vecg_swap_range(vector_gn_t* vec, size_t start_index0, size_t start_index1, size_t items_count);

CTSL_API iterator_t* vecg_create_iterator(vector_gn_t* vec);
CTSL_API void vecg_delete_iterator(iterator_t* iterator);
CTSL_API void vecg_reset_iterator(iterator_t* iterator);

#endif //CTSL_VECTOR_GN_H
