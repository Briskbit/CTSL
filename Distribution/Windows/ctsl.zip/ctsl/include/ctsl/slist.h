/******************************************************************************************************************************************
 *
 * C Tools Library (CTSL)
 *
 * Copyright (C) 2022 Roland Mishaev (rmishaev@gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************************************/

#ifndef CTSL_SLIST_H
#define CTSL_SLIST_H

#include "defs.h"

//Single List: may contain as values different data types in same vector like Python List

CTSL_API slist_t* slist_create(ctl_before_destroy destroy_fn, ctl_compare compare_fn);
CTSL_API STATUS slist_delete(slist_t* list);
CTSL_API size_t slist_size(slist_t* list);
CTSL_API STATUS slist_insert(slist_t* list, size_t index, void* item, size_t item_size, object_type_t item_type);
CTSL_API STATUS slist_push_head(slist_t* list, void* item, size_t item_size, object_type_t item_type);
CTSL_API STATUS slist_push_back(slist_t* list, void* item, size_t item_size, object_type_t item_type);
CTSL_API object_t* slist_pop(slist_t* list, size_t index);
CTSL_API object_t* slist_pop_head(slist_t* list);
CTSL_API object_t* slist_pop_back(slist_t* list);
CTSL_API STATUS slist_replace_item(slist_t* list, void* old_item, void* item, size_t item_size, object_type_t item_type);
CTSL_API STATUS slist_replace_item_by_index(slist_t* list, size_t index, void* item, size_t item_size, object_type_t item_type);
CTSL_API STATUS slist_remove_item(slist_t* list, void* item); /* uses binary compare in case of compare_fn == NULL */
CTSL_API STATUS slist_remove_item_by_index(slist_t* list, size_t index);
CTSL_API STATUS slist_contains_item(slist_t* list, void* item, size_t item_size, object_type_t item_type, size_t* out_index);   /* uses binary compare in case of compare_fn == NULL, in case if out_index!=NULL will return the item's index */

CTSL_API iterator_t* slist_create_iterator(slist_t* list);
CTSL_API void slist_delete_iterator(iterator_t* iterator);
CTSL_API void slist_reset_iterator(iterator_t* iterator);



#endif //CTSL_SLIST_H
